import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CallapiService {
  static getUserList() {
    throw new Error("Method not implemented.");
  }

  private REST_API_SERVER = "http://pit.dd:8083/";
  private DRUPAL_API = "http://api.dd:8083/";
  http: any;
  jsonHeader:any =new HttpHeaders().set('Content-Type', 'application/json');
  token: string;
  dat: string;
  datab : any;

 

  constructor(private httpClient: HttpClient) { }

  public getToken(){
    return this.httpClient.get(this.DRUPAL_API+'/rest/session/token?_format=json',{headers: this.jsonHeader,responseType: 'text'}).subscribe((data:any)=>{
        let s = data; 
        return this.datab = JSON.stringify(s);
    });
  }
  public getUserList(){
        return this.httpClient.get(this.REST_API_SERVER+'/json/users');
  }

  public loginUser(data: any){
    console.log('ss function');
    console.log(data.get('name'));
    return this.httpClient.get(this.REST_API_SERVER+'/json/login?name='+data.get('name')+'&password='+data.get('password'),{headers: this.jsonHeader});

}

public loginUserWithoutObserversable(data:any) {
  return this.httpClient.post(this.REST_API_SERVER+'/api/user/login.php',data)
          .subscribe((data:any)=>{
              let s = data;
            return this.dat = JSON.stringify(s);
             
          });       
}

  public fusercreate(data: any){
    console.log(data);
    console.log('fusercreate function');
    return this.httpClient.post(this.REST_API_SERVER+'/api/user/signup.php', data).subscribe(_event => {  
      console.log('done')
    });
}

isLogin(){
  return !!localStorage.getItem('token');
}
} 
