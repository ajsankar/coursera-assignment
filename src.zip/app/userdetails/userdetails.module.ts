import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserdetailsComponent } from './userdetails.component';
import { UserdetailsRoutes } from './userdetails.routing';
import { RouterModule } from '@angular/router';
import { DemoMaterialModule } from '../demo-material-module';



@NgModule({
  declarations: [UserdetailsComponent],
  imports: [
    CommonModule,DemoMaterialModule,
    RouterModule.forChild(UserdetailsRoutes)
  ]
})
export class UserdetailsModule { }
