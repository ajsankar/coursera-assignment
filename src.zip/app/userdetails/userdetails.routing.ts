import { Routes } from '@angular/router';
import { UserdetailsComponent } from './userdetails.component';


export const UserdetailsRoutes: Routes = [{
  path: '',
  component: UserdetailsComponent
}];
