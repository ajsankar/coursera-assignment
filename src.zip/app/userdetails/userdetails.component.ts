import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator,MatTableModule, MatSort} from '@angular/material';
//,MatTableModule,MatTableDataSource,MatSort,
import { CallapiService } from '../callapi.service';


export interface UserData {
  name: string;
  uid :number;
  created:string;
  profile:string;
}



/**
 * @title Data table with sorting, pagination, and filtering.
 */
@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  displayedColumns: string[] = ['Userid', 'Email', 'Created', 'Profile'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;


  constructor(private dataService: CallapiService ) {
 
    // Assign the data to the data source for the table to render
    
     this.dataService.getUserList().subscribe((data: any[])=>{

      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  
  }
 
  ngOnInit() {

    
  
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    console.log(this.dataSource);
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage(); 
    }
  }
}
