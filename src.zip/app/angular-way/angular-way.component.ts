import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-way',
  templateUrl: './angular-way.component.html',
  styleUrls: ['./angular-way.component.css']
})
export class AngularWayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
