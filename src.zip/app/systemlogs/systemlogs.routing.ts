import { Routes } from '@angular/router';
import { SystemlogsComponent } from './systemlogs.component';


export const SystemlogsRoutes: Routes = [{
  path: '',
  component: SystemlogsComponent
}];
