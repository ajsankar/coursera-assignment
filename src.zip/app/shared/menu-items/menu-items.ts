import { Injectable } from '@angular/core';

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
}

const MENUITEMS = [
  { state: 'dashboard', name: 'Dashboard', type: 'link', icon: 'av_timer' },
  { state: 'user', name: 'User Details', type: 'link', icon: 'view_list' },
  { state: 'logs', name: 'System Log', type: 'link', icon: 'web' }, 
  { state: 'product', type: 'link', name: 'Product Page', icon: 'crop_7_5' }, 
  
];

@Injectable()
export class MenuItems {
  getMenuitem(): Menu[] {
    return MENUITEMS;
  }
}
