import { Component, OnInit } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { CallapiService } from '../callapi.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  dat: string;
  jsonHeader: any;
  responseType:any;
  constructor(private dataService: CallapiService, private http: HttpClient,private router: Router) { 
    
  }
  public edited = false;
  ngOnInit(): void {

  }
  onSubmit(form: NgForm) { 
    
    let rep = <any>[];
    console.log(form.value.username);
    console.log(form.value.password);
    var formData = new FormData();
    formData.append('name',form.value.username);
    formData.append('password',form.value.password);
    //this.dataService.loginUserWithoutObserversable(formData);
    this.dataService.loginUser(formData).subscribe((data:any)=>{
      let s = data;
      console.log(JSON.stringify(s));
      this.dat = JSON.stringify(s);
       console.log(s['status']);
     /*  if(JSON.stringify(s['status']) === 'false'){
         console.log('error');
        this.edited = true;
       }else{
        console.log('else');
        localStorage.setItem('token', s['status']);
        this.router.navigate(['/dashboard'])
       }
     */
  });

console.log(this.dat);
   
  }
}
