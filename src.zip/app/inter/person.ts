export class Person {
    id: number;
    server: string;
    time: string;

}