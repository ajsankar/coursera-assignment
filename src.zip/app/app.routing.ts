import { Routes } from '@angular/router';

import { FullComponent } from './layouts/full/full.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { ProductComponent } from './product/product.component';

export const AppRoutes: Routes = [
  {
    path: 'login',
    component: UserloginComponent,
    data: { title: 'User Login' }
  },
  {
    
    path: '',
    component: FullComponent,
    children: [
      {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      {
        path: 'user',
        loadChildren: () => import('./userdetails/userdetails.module').then(m => m.UserdetailsModule)
      },
      {
        path: 'logs',
        loadChildren: () => import('./systemlogs/systemlogs.module').then(m => m.SystemlogsModule)
      },
      {
      path: 'product',
      component: ProductComponent,
      data: { title: 'product' }
      }
    ]
  }
];
